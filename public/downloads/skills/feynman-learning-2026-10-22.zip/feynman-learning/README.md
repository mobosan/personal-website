# 费曼学习陪练 · feynman-learning

一套可携带的 Agent Skill，用于任意知识领域的学习计划、解释陪练、掌握验证与持续复习。默认中文交流，也可随学习者语言切换。

核心循环是：**你先讲 → AI 追问 → 发现缺口 → 最少量补课 → 无提示变式 → 延迟验证 → 更新计划**。

这是一套教学工作流和记录约定。它不会仅凭“我听懂了”提高掌握层级，也不会在没有调度功能时自动发送提醒。

## 下载与安装

解压 `feynman-learning.zip`，得到整个 `feynman-learning/` 文件夹。复制整个文件夹，不要只复制 SKILL.md，也不要多嵌套一层同名文件夹。

| 工具 | 推荐个人安装目录 | 项目内安装目录 | 显式调用 |
| --- | --- | --- | --- |
| Codex | `~/.agents/skills/feynman-learning/` | `<项目>/.agents/skills/feynman-learning/` | `$feynman-learning` |
| Claude Code | `~/.claude/skills/feynman-learning/` | `<项目>/.claude/skills/feynman-learning/` | `/feynman-learning` |

Windows 的 `~` 指用户目录，例如 `%USERPROFILE%`。如安装 Codex，最终应能找到 `%USERPROFILE%\.agents\skills\feynman-learning\SKILL.md`。目录不存在时先创建；已有同名 Skill 时先备份，避免覆盖个人修改。通常只选个人或项目中的一个位置，避免重复发现。

Codex 的个人及项目发现路径依据 [官方 Build skills 文档](https://learn.chatgpt.com/docs/build-skills)；Claude Code 路径与调用方法依据 [官方 Skills 文档](https://code.claude.com/docs/en/skills)。本文核对日期为 2026-09-24。安装后在新会话中查看可用技能并显式调用；若当前客户端采用不同的托管安装方式，按该客户端说明导入。下载文件本身不等于已经安装。

本包采用 [Agent Skills 规范](https://agentskills.io/specification)的 SKILL.md＋YAML 元数据＋相对资源引用。`agents/openai.yaml` 提供可选 Codex 界面信息；其他兼容工具可忽略它。没有供应商专属工具、API 密钥或网络依赖。核心工作流不需要 Python；可选档案检查工具需要 Python 3.9+ 标准库。

## 开始使用

在 Codex 中输入：

```text
用 $feynman-learning 帮我学线性代数。
我会高中数学，每周能投入 3 小时，目标是理解机器学习中的矩阵运算。
请先诊断基础，再制定可调整的计划，一次问一个主要问题。
```

在 Claude Code 中，把开头改成：

```text
/feynman-learning 帮我学线性代数。我会高中数学，每周 3 小时，目标是理解机器学习中的矩阵运算。先诊断，再制定计划。
```

其他常用请求：

- “这是我对梯度下降的解释，请找出我真正没懂的地方。”
- “继续学习缓存，先读 `learning/cache/state.json`，今天只有 15 分钟。”
- “我想学习摄影构图，每周 2 小时，以能分析并改进自己的照片为目标。”
- “根据这周的错误调整计划，告诉我哪些能力已经有证据，哪些还没验证。”
- “今天只想先听讲解；等我愿意时再测验。”

只询问一个事实时，它不应自动展开长期学习计划。用户可随时要求多讲一点、减少问题、修改目标或停止记录。

## 掌握度怎样反馈

| 层级 | 含义 |
| --- | --- |
| L0 | 未验证，或尚未建立可用证据 |
| L1 | 听懂与识别 |
| L2 | 无提示复述 |
| L3 | 解释机制、例子和边界 |
| L4 | 独立应用于不同任务 |
| L5 | 在新情境中迁移、推导或修正 |

每个节点另外记录 0–3 分的能力维度、证据强度和复习状态。未测项为 null；分数不直接相加换算百分比。具体门槛见 [掌握度规则](references/assessment.md)。它们是实用教学约定，不是科学标定量表。

## 学习档案保存在哪里

默认在你当前的可写学习工作区创建 `learning/<项目名>/state.json`，保存目标、知识地图、计划、证据、错误与复习日期；不会写进 Skill 安装目录。首次使用时会说明实际位置。

没有文件权限或选择不保存时，AI 应提供可复制 JSON 快照，不承诺跨会话自动记忆。换工具时，将自己的 state.json 放到新工具可读取的位置，并明确让它继续该项目。包里的 example-state.json 只是虚构示例，不是你的学习历史。

可选检查命令（由 Agent 执行即可）：

```text
python /path/to/feynman-learning/scripts/check_state.py /path/to/learning/project/state.json
```

检查工具只读文件，发现结构、引用或部分评分约束问题时返回错误；它不负责判断学习者答案的正确性或自动评级。

## 完整目录

```text
feynman-learning/
├── SKILL.md                     触发条件与主要工作流
├── README.md                    安装、调用和使用说明
├── VALIDATION.md                验证范围与限制
├── agents/
│   └── openai.yaml              可选 Codex 界面元数据
├── references/
│   ├── assessment.md            评分、晋级、证据与反馈
│   ├── planning.md              计划调整与间隔复习
│   ├── state.md                 持久化格式与恢复约定
│   └── examples.md              数学、AI/编程、人文等示例
├── assets/
│   ├── state-template.json      新项目空白档案
│   ├── node-template.json       新知识节点模板
│   └── example-state.json       完整虚构学习档案
└── scripts/
    └── check_state.py           可选、只读的结构检查工具
```

升级时替换 Skill 文件夹，自己的 learning 目录单独保留。若自行修改评分门槛，同时更新相关示例及说明；不要把新规则偷偷套到旧表现上而丢失历史依据。
