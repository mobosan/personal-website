#!/usr/bin/env python3
"""Read-only structural checks for Feynman learning state 1.0; Python 3.9+."""

import argparse
import datetime as dt
import json
from pathlib import Path
import re
import sys


DIMENSIONS = ("recognition", "recall", "explanation", "application", "transfer")


def nullable(spec):
    return ("nullable", spec)


def array(spec):
    return ("array", spec)


def enum(*values):
    return ("enum", values)


def integer(low=0, high=None):
    return ("integer", low, high)


TEXT = "text"
DATE = "date"
STRINGS = array(TEXT)
SCORE = integer(0, 3)
PROFILE = {
    **{key: nullable(TEXT) for key in ("domain", "goal", "deliverable", "timezone", "language")},
    **{key: STRINGS for key in ("background", "preferences", "assumptions")},
    "weekly_minutes": nullable(integer(1)),
    "session_minutes": nullable(integer(1)),
    "deadline": nullable(DATE),
}
NODE = {
    **{key: TEXT for key in ("id", "title", "objective", "assessment_note")},
    "target_level": integer(1, 5),
    "priority": enum("core", "optional"),
    "status": enum("unstarted", "learning", "practicing", "maintaining", "paused"),
    "dimensions": {key: nullable(SCORE) for key in DIMENSIONS},
    "level": integer(0, 5),
    "confidence": enum("unverified", "tentative", "supported", "retained"),
    "basis_evidence_ids": STRINGS,
    "missing_evidence": STRINGS,
    "review": {
        "stage": integer(0, 4),
        "due_on": nullable(DATE),
        "status": enum("unscheduled", "scheduled", "due", "overdue", "recheck"),
        "last_reviewed_on": nullable(DATE),
        "last_outcome": nullable(enum("independent_pass", "assisted", "fail")),
    },
}
EVIDENCE = {
    **{key: TEXT for key in ("id", "node_id", "session_id", "task", "task_family",
                             "learner_response", "learner_work", "rationale")},
    "date": DATE,
    "criteria": STRINGS,
    "hint_level": integer(0, 3),
    "exposure": enum("fresh", "immediate_variant", "repeated", "delayed_variant"),
    "conditions": enum("closed_book", "open_reference", "solution_visible"),
    "allowed_resources": STRINGS,
    "scores": ("scores",),
    "result": enum("pass", "partial", "fail", "unscored"),
    "supersedes": nullable(TEXT),
}
ERROR = {
    **{key: TEXT for key in ("id", "node_id", "observation", "hypothesis", "repair")},
    "kind": enum("conceptual", "prerequisite", "procedural", "slip", "expression", "ambiguous"),
    "evidence_ids": STRINGS,
    "status": enum("open", "repairing", "resolved"),
    "resolution_evidence_ids": STRINGS,
}
SESSION = {
    "id": TEXT, "date": DATE, "minutes": nullable(integer()),
    "summary": TEXT, "next_action": nullable(TEXT),
}
TASK = {
    "id": TEXT, "node_id": TEXT,
    "kind": enum("diagnose", "learn", "explain", "practice", "transfer", "review"),
    "minutes": integer(), "due_on": nullable(DATE), "success_criteria": TEXT,
    "status": enum("planned", "done", "deferred", "cancelled"),
}
PLAN = {
    "version": integer(), "week_start": nullable(DATE),
    "budget_minutes": nullable(integer(1)), "tasks": array(TASK),
    "changes": array({
        "version": integer(), "date": DATE, "reason": TEXT,
        "evidence_ids": STRINGS, "impact": TEXT,
    }),
}
STATE = {
    "schema_version": enum("1.0"), "revision": integer(),
    "project_id": nullable("project_id"), "updated_at": nullable("timestamp"),
    "profile": PROFILE, "nodes": array(NODE),
    "links": array({"from": TEXT, "to": TEXT,
                    "type": enum("prerequisite", "related", "contrast"), "reason": TEXT}),
    "evidence": array(EVIDENCE), "errors": array(ERROR), "sessions": array(SESSION),
    "plan": PLAN, "next_action": nullable(TEXT),
}


def check_shape(value, spec, path, errors):
    """Validate every required field before any relational checks use indexing."""
    def bad(message):
        errors.append("{}: {}".format(path, message))

    if isinstance(spec, dict):
        if not isinstance(value, dict):
            bad("expected an object")
            return
        for key in sorted(set(spec) - set(value)):
            bad("missing required field '{}'".format(key))
        for key in sorted(set(value) - set(spec)):
            bad("unknown field '{}' (schema 1.0)".format(key))
        for key in spec.keys() & value.keys():
            check_shape(value[key], spec[key], path + "." + key, errors)
    elif isinstance(spec, tuple):
        kind = spec[0]
        if kind == "nullable":
            if value is not None:
                check_shape(value, spec[1], path, errors)
        elif kind == "array":
            if not isinstance(value, list):
                bad("expected an array")
            else:
                for i, item in enumerate(value):
                    check_shape(item, spec[1], "{}[{}]".format(path, i), errors)
        elif kind == "enum":
            if not isinstance(value, str) or value not in spec[1]:
                bad("expected one of {}".format(", ".join(spec[1])))
        elif kind == "integer":
            if type(value) is not int or value < spec[1] or (spec[2] is not None and value > spec[2]):
                bad("expected integer {}..{} (booleans are not numbers)".format(
                    spec[1], spec[2] if spec[2] is not None else "unbounded"))
        elif kind == "scores":
            if not isinstance(value, dict):
                bad("expected an object of tested dimension scores")
            else:
                for key, score in value.items():
                    if key not in DIMENSIONS:
                        bad("unknown score dimension '{}'".format(key))
                    else:
                        check_shape(score, SCORE, path + "." + key, errors)
    elif not isinstance(value, str) or not value.strip():
        bad("expected a nonempty string")
    elif spec == "project_id":
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", value):
            bad("use lowercase letters/digits separated by single hyphens")
    elif spec == DATE:
        try:
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
                raise ValueError
            dt.date.fromisoformat(value)
        except ValueError:
            bad("expected a valid date YYYY-MM-DD")
    elif spec == "timestamp":
        try:
            pattern = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})"
            if not re.fullmatch(pattern, value):
                raise ValueError
            if value[-1] != "Z" and (int(value[-5:-3]) > 23 or int(value[-2:]) > 59):
                raise ValueError
            parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.utcoffset() is None:
                raise ValueError
        except ValueError:
            bad("expected ISO 8601 timestamp with seconds and timezone, e.g. 2026-09-24T10:00:00+08:00")


def has_cycle(graph):
    """Kahn's algorithm avoids recursion depth limits for large maps."""
    indegree = {key: 0 for key in graph}
    for targets in graph.values():
        for target in targets:
            indegree[target] += 1
    pending = [key for key, degree in indegree.items() if degree == 0]
    visited = 0
    while pending:
        key = pending.pop()
        visited += 1
        for target in graph[key]:
            indegree[target] -= 1
            if indegree[target] == 0:
                pending.append(target)
    return visited != len(graph)


def validate(state, template=False):
    errors, warnings = [], []
    check_shape(state, STATE, "$", errors)
    if errors:
        return errors, warnings

    blank = (state["revision"] == 0 and state["plan"]["version"] == 0
             and all(not state[key] for key in ("nodes", "links", "evidence", "errors", "sessions"))
             and not state["plan"]["tasks"] and not state["plan"]["changes"])
    for key in ("project_id", "updated_at"):
        if state[key] is None and not (template and blank):
            errors.append("$.{}: required for real records; null is only allowed for a blank --template".format(key))

    indexes = {}
    for collection in ("nodes", "evidence", "errors", "sessions", "tasks"):
        records = state["plan"]["tasks"] if collection == "tasks" else state[collection]
        index = {}
        for record in records:
            if record["id"] in index:
                errors.append("{}: duplicate id '{}'".format(collection, record["id"]))
            index[record["id"]] = record
        indexes[collection] = index

    def ref(value, collection, path, node_id=None):
        record = indexes[collection].get(value)
        if record is None:
            errors.append("{}: unknown {} id '{}'".format(path, collection, value))
        elif node_id is not None and record["node_id"] != node_id:
            errors.append("{}: evidence '{}' belongs to another node".format(path, value))
        return record

    def refs(values, path, node_id=None):
        if len(set(values)) != len(values):
            errors.append("{}: duplicate evidence ids".format(path))
        return [ref(value, "evidence", path, node_id) for value in values]

    prerequisite = {key: set() for key in indexes["nodes"]}
    for i, link in enumerate(state["links"]):
        path = "links[{}]".format(i)
        start = ref(link["from"], "nodes", path + ".from")
        end = ref(link["to"], "nodes", path + ".to")
        if link["type"] == "prerequisite" and start is not None and end is not None:
            prerequisite[link["from"]].add(link["to"])
    if has_cycle(prerequisite):
        errors.append("links: prerequisite relationships contain a cycle")

    replaced, seen = set(), set()
    for record in state["evidence"]:
        path = "evidence[{}]".format(record["id"])
        ref(record["node_id"], "nodes", path + ".node_id")
        session = ref(record["session_id"], "sessions", path + ".session_id")
        if session and record["date"] != session["date"]:
            errors.append(path + ".date: must match the referenced session date")
        if not record["criteria"]:
            errors.append(path + ".criteria: include at least one task-specific criterion")
        if record["result"] != "unscored" and not record["scores"]:
            errors.append(path + ".scores: scored results require at least one dimension")
        cap = 3
        if record["hint_level"] > 0 or record["conditions"] == "solution_visible" or record["exposure"] == "repeated":
            cap = 1
        elif record["exposure"] == "immediate_variant":
            cap = 2
        if any(score > cap for score in record["scores"].values()):
            errors.append(path + ".scores: hint/exposure/conditions limit every score to {}".format(cap))
        previous = record["supersedes"]
        if previous is not None:
            ref(previous, "evidence", path + ".supersedes", record["node_id"])
            if previous not in seen:
                errors.append(path + ".supersedes: must point to an earlier record (no forward references or cycles)")
            if previous in replaced:
                errors.append(path + ".supersedes: correction branches; point to the latest correction instead")
            replaced.add(previous)
        seen.add(record["id"])

    for node in state["nodes"]:
        path = "nodes[{}]".format(node["id"])
        basis = refs(node["basis_evidence_ids"], path + ".basis_evidence_ids", node["id"])
        if set(node["basis_evidence_ids"]) & replaced:
            errors.append(path + ".basis_evidence_ids: includes superseded evidence")
        if (node["level"] > 0 or any(value is not None for value in node["dimensions"].values())) and not basis:
            errors.append(path + ": scores and levels above zero require basis evidence")
        for dimension, score in node["dimensions"].items():
            if score is not None and not any(item and dimension in item["scores"] for item in basis):
                errors.append(path + ".dimensions.{}: no basis evidence scores this dimension".format(dimension))

    for record in state["errors"]:
        path = "errors[{}]".format(record["id"])
        ref(record["node_id"], "nodes", path + ".node_id")
        refs(record["evidence_ids"], path + ".evidence_ids", record["node_id"])
        resolution = refs(record["resolution_evidence_ids"], path + ".resolution_evidence_ids", record["node_id"])
        if record["status"] == "resolved" and not any(
            item and item["id"] not in replaced and item["hint_level"] == 0
            and item["exposure"] in ("fresh", "delayed_variant")
            and item["conditions"] != "solution_visible" and item["result"] == "pass"
            for item in resolution
        ):
            errors.append(path + ": resolved errors need current independent passing resolution evidence")

    plan = state["plan"]
    for task in plan["tasks"]:
        ref(task["node_id"], "nodes", "plan.tasks[{}].node_id".format(task["id"]))
    versions = set()
    for i, change in enumerate(plan["changes"]):
        path = "plan.changes[{}]".format(i)
        refs(change["evidence_ids"], path + ".evidence_ids")
        if change["version"] > plan["version"] or change["version"] in versions:
            errors.append(path + ".version: must be unique and no greater than plan.version")
        versions.add(change["version"])
    total = sum(task["minutes"] for task in plan["tasks"] if task["status"] in ("planned", "done"))
    if plan["budget_minutes"] is not None and total > plan["budget_minutes"]:
        warnings.append("plan: planned + done time {} exceeds budget {}; preserve actual time, explain the overrun in changes, and adjust remaining tasks".format(total, plan["budget_minutes"]))
    return errors, warnings


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("duplicate JSON key '{}'".format(key))
        obj[key] = value
    return obj


def invalid_constant(value):
    raise ValueError("invalid JSON constant '{}'".format(value))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("state", type=Path, help="UTF-8 state.json to check (never modified)")
    parser.add_argument("--template", action="store_true", help="allow null project_id/updated_at in a blank template")
    args = parser.parse_args(argv)
    try:
        with args.state.open(encoding="utf-8-sig") as stream:
            state = json.load(stream, object_pairs_hook=unique_object, parse_constant=invalid_constant)
        errors, warnings = validate(state, args.template)
    except (OSError, UnicodeError, ValueError, RecursionError) as exc:
        print("ERROR: cannot read/validate {}: {}".format(args.state, exc), file=sys.stderr)
        return 1
    for message in warnings:
        print("WARNING: " + message)
    for message in errors:
        print("ERROR: " + message, file=sys.stderr)
    if errors:
        print("FAILED: {} error(s); file was not changed.".format(len(errors)), file=sys.stderr)
        return 1
    print("OK: mechanical checks passed; file was not changed.")
    print("Answer correctness, independence, task diversity, and mastery levels still require human/agent review.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
