# 学习档案约定（schema_version 1.0）

## 保存与恢复

每个学习项目使用一个独立目录，默认 `learning/<project-id>/`；`project-id` 使用简短的小写字母、数字与单连字符（如 `linear-algebra`），不包含姓名或路径分隔符。相对位置基于当前可写学习工作区，不基于 Skill 安装目录。

`state.json` 是唯一事实源，UTF-8 JSON；可选 `progress.md` 是从它生成的便于阅读的摘要，不反向覆盖状态。时间预算、地图、分数和证据都放在一个文件，避免多文件局部写入造成不同步。

首次从 assets/state-template.json 复制，再填写已知值；null 表示未知，空数组表示尚无记录。模板的 project_id 和 updated_at 为 null，真实保存时必须填入。增加节点时参考 assets/node-template.json，不把示例项目误当成真实用户历史。

每次有实质证据、约束或计划变化后保存。保存前读取最新 revision；在内存里更新，将 revision 加 1，updated_at 写成带时区的 ISO 8601 时间。先写同目录临时文件并检查，再替换 state.json；可保留上一次 state.backup.json。发现 revision 已变化则重读合并，避免并发覆盖；不支持锁时按单写入者使用，不声称可防所有并发竞争。

若写入失败，保留旧文件，说明尚未保存并提供可复制 JSON。恢复时先检查 schema_version；未知版本不静默转换。文件损坏先保留原件再尝试备份；没有有效副本时依据用户提供的快照恢复，不编造历史。

## 顶层字段

| 字段 | 类型与含义 |
| --- | --- |
| schema_version | 固定字符串 `1.0` |
| revision | 非负整数；真实每次保存加 1 |
| project_id | 项目标识；仅空白模板可为 null |
| updated_at | 带 UTC 偏移的 ISO 8601 时间；仅模板可为 null |
| profile | 领域、目标、成果、基础、weekly_minutes、session_minutes、deadline、timezone、language、preferences、assumptions；未知标量可为 null |
| nodes | 知识节点数组，见下文 |
| links | 关系数组：`{from, to, type, reason}`；type 为 prerequisite / related / contrast |
| evidence | 作答证据数组，只追加新记录；更正见下文 |
| errors | 错误／薄弱点数组 |
| sessions | 会话摘要数组 |
| plan | 当前周计划及变更历史 |
| next_action | 简短的下一步任务；还没决定时 null |

profile.background、preferences、assumptions 都是字符串数组；weekly_minutes 和 session_minutes 是正整数或 null；deadline 为 YYYY-MM-DD 或 null；timezone 使用用户提供或环境可靠提供的时区名称。每个项目只对应一位学习者。

## 节点 nodes

字段由 node-template.json 给出。id 必须唯一且稳定，title 为概念名，objective 为可检验目标。target_level 为 1–5，priority 为 core / optional，status 为 unstarted / learning / practicing / maintaining / paused。

dimensions 固定含 recognition、recall、explanation、application、transfer，各为 null 或整数 0–3；level 为 0–5；confidence 为 unverified / tentative / supported / retained。层级门槛、提示上限、证据强度按 assessment.md 判断。

basis_evidence_ids 列出当前判断使用的证据，必须属于该节点。assessment_note 解释结论及矛盾；missing_evidence 是字符串数组，指明下一次要测什么。凡有非 null 评分或 level 大于 0 都必须有依据。

review 含 stage（0–4）、due_on（日期或 null）、status（unscheduled / scheduled / due / overdue / recheck）、last_reviewed_on（日期或 null）、last_outcome（null / independent_pass / assisted / fail）。日期更新方法见 planning.md。review.status 是基于会话日期刷新后的显示值，不替代作答证据。

## 作答证据 evidence

每条包含以下字段，未测维度不出现在 scores 中：

```json
{
  "id": "ev-001",
  "node_id": "n-001",
  "session_id": "s-001",
  "date": "2026-09-24",
  "task": "具体题目或可定位的练习引用",
  "task_family": "mechanism-explanation",
  "criteria": ["本题具体过关点，不写笼统的答对即可"],
  "learner_response": "保留关键原话或忠实摘要，注明摘要",
  "learner_work": "哪些解释、步骤或作品由学习者完成",
  "hint_level": 0,
  "exposure": "fresh",
  "conditions": "closed_book",
  "allowed_resources": [],
  "scores": {"recall": 2},
  "rationale": "该评分对应的具体表现和缺口",
  "result": "partial",
  "supersedes": null
}
```

result 为 pass / partial / fail / unscored，针对本题判据，不代表节点毕业。unscored 可用空 scores；其他结果至少有一项评分。scores 值只用 0–3；无证据维度省略，不填猜测值。

task_family 表示题目类型，用来识别重复证据；是否有实质变化仍需人工判断。date 为实际作答日；session_id 必须指向 sessions 中的一次会话。不能为错过的复习补造日期或答案。

如果旧记录评分错了，追加一条更正记录并以 supersedes 指向旧证据，同一 node_id；保留旧记录。统计和选用依据时忽略已被替代的记录，不能把原记录和更正记录计为两次尝试。当前 basis_evidence_ids 不得指向已被替代的证据。重复更正应指向最新更正版本，不产生分叉或环。

## 错误 errors

```json
{
  "id": "err-001",
  "node_id": "n-001",
  "kind": "conceptual",
  "observation": "用户的具体误解或受阻表现",
  "hypothesis": "可能根因；未确认就写推测",
  "evidence_ids": ["ev-001"],
  "repair": "计划使用的补缺任务",
  "status": "open",
  "resolution_evidence_ids": []
}
```

kind 为 conceptual / prerequisite / procedural / slip / expression / ambiguous；status 为 open / repairing / resolved。解决后保留错误，至少以一次相应的无提示新证据说明修复，不能只因 AI 讲过就标 resolved。表达困难或资料不确定不应直接写成概念错误。

## 会话 sessions

每条为 `{id, date, minutes, summary, next_action}`。minutes 是实际用时的非负整数或 null；未知不要用计划时间代填。summary 简短说明本次做了什么、哪里仍未验证，next_action 为字符串或 null。

## 周计划 plan

version 为非负整数；week_start 为本周开始日期或 null；budget_minutes 为正整数或 null。tasks 每项：

```json
{
  "id": "t-001",
  "node_id": "n-001",
  "kind": "diagnose",
  "minutes": 10,
  "due_on": null,
  "success_criteria": "本次任务的可观察完成标准",
  "status": "planned"
}
```

kind 为 diagnose / learn / explain / practice / transfer / review；status 为 planned / done / deferred / cancelled。minutes 是非负整数；done 任务改记实际用时，planned 保留预计时间。当前周 planned 与 done 合计不得超过 budget_minutes；若实际超出则保留真实用时并在 changes 解释超支，移出或减少尚未做的任务。检查脚本会提示超支，不能为消除提示改小真实用时。

changes 每项为 `{version, date, reason, evidence_ids, impact}`，证据驱动变更附证据 ID；因用户时间或目标变化时可为空数组，reason 写明用户约束。变更时 version 加 1。跨周滚动时更新 week_start，在 changes 的 impact 概括已完成、未完成与移转项，再替换当前 tasks；详细作答历史留在 evidence/sessions 中。

## 最低一致性检查

运行 scripts/check_state.py 检查 JSON、类型、范围、ID、引用、前置环、日期格式及可机械验证的提示上限。用 `--template` 可检查空白状态模板。脚本不会判断原理对错、任务是否足够不同、用户是否独立作答，亦不自动推导层级；这些仍需依据 assessment.md 复核。

概念状态与评分要能追溯到证据；保留缺口，不以漂亮报告覆盖矛盾。需要精简上下文时先读取相关节点与其证据，文件本身不自动删除。只有用户要求归档时才另存历史，并在新的状态中保留可解析的历史方式；未经定义的归档引用不写进 1.0 格式。

## 无文件能力时

提供一个含所有必要字段的 JSON 代码块，标明“本会话快照，未保存到磁盘”。用户可将快照交给下次会话；不要声称跨会话自动记忆。资料很多时提供下载文件（若宿主支持），而不是只给无法恢复的摘要。
